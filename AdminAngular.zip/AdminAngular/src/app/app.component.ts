﻿import { Component } from '@angular/core';

@Component({
    // tslint:disable-next-line: component-selector
    selector: 'app',
    templateUrl: 'app.component.html'
})

export class AppComponent { }
