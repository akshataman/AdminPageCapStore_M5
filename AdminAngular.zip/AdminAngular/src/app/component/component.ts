﻿import { Component } from '@angular/core';

@Component({
    selector: 'app',
    templateUrl: 'component.html'
})

export class AppComponent { }