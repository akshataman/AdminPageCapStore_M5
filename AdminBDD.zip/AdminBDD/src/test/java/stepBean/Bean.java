package stepBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Bean {
	
	WebDriver driver;
	
	@FindBy(id="user")
	@CacheLookup
	WebElement user;
	
	@FindBy(id="merchant")
	@CacheLookup
	WebElement merchant;

	@FindBy(id="product")
	@CacheLookup
	WebElement product;

	@FindBy(id="discount")
	@CacheLookup
	WebElement discount;
	
	@FindBy(id="promocode")
	@CacheLookup
	WebElement promocode;
	
	public Bean(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver,this);
		
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUser() {
		return user;
	}

	public void setUser() {
		this.user.click();
	}

	public WebElement getMerchant() {
		return merchant;
	}

	public void setMerchant() {
		this.merchant.click();
	}

	public WebElement getProduct() {
		return product;
	}

	public void setProduct() {
		this.product.click();
	}

	public WebElement getDiscount() {
		return discount;
	}

	public void setDiscount() {
		this.discount.click();
	}

	public WebElement getPromocode() {
		return promocode;
	}

	public void setPromocode() {
		this.promocode.click();
	}
	
}
