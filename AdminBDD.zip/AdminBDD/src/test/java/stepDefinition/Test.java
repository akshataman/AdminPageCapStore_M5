package stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepBean.Bean;

public class Test {
	
	private WebDriver driver;
	private Bean bean;
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"D:\\Selenium\\chromedriver_win32\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	
@Given("^Admin is on Admin Home Page$")
public void admin_is_on_Admin_Home_Page() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
	driver.get("D:\\Users\\akaman\\BDD_Workspace\\AdminBDD\\adminHome.html");
	bean = new Bean(driver);
}

@When("^Admin clicks on User Details Link$")
public void admin_clicks_on_User_Details_Link() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
	bean.setUser();
}

@Then("^User Details Page is opened$")
public void user_Details_Page_is_opened() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
	driver.get("D:\\Users\\akaman\\BDD_Workspace\\AdminBDD\\user.html");
	Thread.sleep(3000);
	driver.close();
}

@When("^Admin clicks on Merchant Details Link$")
public void admin_clicks_on_Merchant_Details_Link() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
	bean.setMerchant();
}

@Then("^Merchant Details Page is opened$")
public void merchant_Details_Page_is_opened() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
	driver.get("D:\\Users\\akaman\\BDD_Workspace\\AdminBDD\\merchant.html");
	Thread.sleep(3000);
	driver.close();
}

@When("^Admin clicks on Product Details Link$")
public void admin_clicks_on_Product_Details_Link() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
	bean.setProduct();
}

@Then("^Product Details Page is opened$")
public void product_Details_Page_is_opened() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
	driver.get("D:\\Users\\akaman\\BDD_Workspace\\AdminBDD\\product.html");
	Thread.sleep(3000);
	driver.close();
}

@When("^Admin clicks on Discount Details Link$")
public void admin_clicks_on_Discount_Details_Link() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
	bean.setDiscount();
}

@Then("^Discount Details Page is opened$")
public void discount_Details_Page_is_opened() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
	driver.get("D:\\Users\\akaman\\BDD_Workspace\\AdminBDD\\discount.html");
	Thread.sleep(3000);
	driver.close();
}

@When("^Admin clicks on PromoCode Details Link$")
public void admin_clicks_on_PromoCode_Details_Link() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
	bean.setPromocode();
}

@Then("^PromoCode Details Page is opened$")
public void promocode_Details_Page_is_opened() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
//    throw new PendingException();
	driver.get("D:\\Users\\akaman\\BDD_Workspace\\AdminBDD\\promocode.html");
	Thread.sleep(3000);
	driver.close();	
}


}
